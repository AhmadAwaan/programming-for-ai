# Object Detection Web App (Flask + OpenCV)

## Description
This is a simple web application where users can upload an image and the app will detect faces using OpenCV's Haarcascade Classifier.

## How to Run
1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Run the server:
   ```
   python app.py
   ```
3. Open your browser and go to:
   ```
   http://127.0.0.1:5000/
   ```

## Technology Stack
- Python
- Flask
- OpenCV

## Future Improvements
- Add object detection using YOLOv5.
- Live webcam detection.
