import os
import cv2
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
UPLOAD_FOLDER = 'static/detected'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load Haarcascade Classifier
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

@app.route('/')
def upload_form():
    return render_template('upload.html')

@app.route('/', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)

    if file:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)

        # Read and detect faces
        img = cv2.imread(filepath)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Save the detected image
        output_path = os.path.join(app.config['UPLOAD_FOLDER'], 'detected_' + file.filename)
        cv2.imwrite(output_path, img)

        return render_template('result.html', filename='detected_' + file.filename)

@app.route('/display/<filename>')
def display_image(filename):
    return redirect(url_for('static', filename='detected/' + filename), code=301)

if __name__ == "__main__":
    app.run(debug=True)
